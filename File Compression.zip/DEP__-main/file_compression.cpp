#include <iostream>
#include <fstream>
#include <string>
using namespace std;
string compress(const string& input) {
    string compressed = "";
    int n = input.length();
    
    for (int i = 0; i < n; i++) {
        int count = 1;
        while (i < n - 1 && input[i] == input[i + 1]) {
            count++;
            i++;
        }
        compressed += input[i] + to_string(count);
    }
    return compressed;
}
string decompress(const string& input) {
    string decompressed = "";
    for (int i = 0; i < input.length(); i++) {
        char ch = input[i];
        string countStr = "";
        
        while (isdigit(input[++i])) {
            countStr += input[i];
        }
        int count = stoi(countStr);
        decompressed.append(count, ch);
        i--;
    }
    return decompressed;
}
string readFile(const string& fileName) {
    ifstream inFile(fileName);
    if (!inFile) {
        cerr << "Error: Unable to open file " << fileName << endl;
        return "";
    }
    string content((istreambuf_iterator<char>(inFile)), istreambuf_iterator<char>());
    inFile.close();
    return content;
}
void writeFile(const string& fileName, const string& data) {
    ofstream outFile(fileName);
    if (!outFile) {
        cerr << "Error: Unable to write to file " << fileName << endl;
        return;
    }
    outFile << data;
    outFile.close();
}
int main() {
    string inputFile = "input.txt";
    string compressedFile = "compressed.txt";
    string decompressedFile = "decompressed.txt";
    string data = readFile(inputFile);
    if (data.empty()) {
        cout << "The input file is empty or cannot be read." << endl;
        return 0;
    }
    string compressedData = compress(data);
    writeFile(compressedFile, compressedData);
    cout << "Compression done. Compressed data saved to " << compressedFile << endl;
    string decompressedData = decompress(compressedData);
    writeFile(decompressedFile, decompressedData);
    cout << "Decompression done. Decompressed data saved to " << decompressedFile << endl;
    return 0;
}
